/* copy.c - copy ONE file (basic, -b, -i, -p, -m, -c resume, -v verify) and the -B benchmark */
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "mycp.h"

#define BAR_WIDTH 30

/* ---------- -i : file information ---------- */

static void print_file_info(const char *label, const char *path, const struct stat *st)
{
    /* rwx bits of user, group, other (0400 .. 0001) as unsigned constants */
    static const unsigned int bits[9] = { 0x100U, 0x80U, 0x40U, 0x20U, 0x10U, 0x8U, 0x4U, 0x2U, 0x1U };
    char size[32];
    char mtime[32];
    char perm[10];
    struct tm tm;
    size_t i;

    for (i = 0U; i < 9U; i++) {
        perm[i] = ((st->st_mode & bits[i]) != 0U) ? "rwxrwxrwx"[i] : '-';
    }
    perm[9] = '\0';
    format_size((unsigned long long)st->st_size, size, sizeof(size));
    (void)localtime_r(&st->st_mtime, &tm);
    (void)strftime(mtime, sizeof(mtime), "%Y-%m-%d %H:%M:%S", &tm);
    say("---- %s file info ----\n  Path        : %s\n  Size        : %lld bytes (%s)\n"
        "  Permissions : %s (%04o)\n  Owner (uid) : %u\n  Inode       : %llu\n  Modified    : %s\n",
        label, path, (long long)st->st_size, size, perm, (unsigned)(st->st_mode & PERM_MASK),
        (unsigned)st->st_uid, (unsigned long long)st->st_ino, mtime);
}

/* ---------- -p : progress bar (single-threaded use only) ---------- */

static int g_last_pct = -1;

static void progress_update(unsigned long long done, unsigned long long total)
{
    int pct;

    if (total == 0ULL) {
        return;
    }
    pct = (int)((done >= total) ? 100ULL : ((done * 100ULL) / total));
    if (pct != g_last_pct) {
        char bar[BAR_WIDTH + 1];
        char d[32];
        char t[32];
        int i;

        g_last_pct = pct;
        for (i = 0; i < BAR_WIDTH; i++) {
            bar[i] = (i < ((pct * BAR_WIDTH) / 100)) ? '#' : '.';
        }
        bar[BAR_WIDTH] = '\0';
        format_size(done, d, sizeof(d));
        format_size(total, t, sizeof(t));
        say("\r[%s] %3d%%  %s / %s", bar, pct, d, t);
    }
}

/* ---------- the copy ---------- */

/* read a block, write the whole block, until EOF */
static int copy_loop(int in, int out, const options_t *opt, unsigned long long start,
                     unsigned long long total, unsigned long long *copied)
{
    char *buf = malloc(opt->buf_size);
    ssize_t n = 1;
    int ret = 0;

    if (buf == NULL) {
        log_msg(LOG_ERROR, "out of memory (buffer %zu bytes)", opt->buf_size);
        return -1;
    }
    while ((n > 0) && (ret == 0)) {
        n = read_full(in, buf, opt->buf_size);
        if (n < 0) {
            log_msg(LOG_ERROR, "read error: %s", strerror(errno));
            ret = -1;
        } else if ((n > 0) && (write_all(out, buf, (size_t)n) < 0)) {
            log_msg(LOG_ERROR, "write error: %s", strerror(errno));
            ret = -1;
        } else {
            *copied += (unsigned long long)n;
            if (opt->progress != 0) {
                progress_update(start + *copied, total);
            }
        }
    }
    if ((opt->progress != 0) && (g_last_pct >= 0)) {
        say("\n");
        g_last_pct = -1;
    }
    free(buf);
    return ret;
}

/* destination side: open it (resume?), copy, chmod, close, show info */
static int copy_to_dst(int in, const struct stat *sst, const char *src, const char *dst,
                       const options_t *opt, unsigned long long *copied)
{
    struct stat dst_st;
    const unsigned long long total = (unsigned long long)sst->st_size;
    int have_dst = 0;
    unsigned long long offset = 0ULL;
    unsigned int flags;
    int out;
    int ret = 0;

    if (stat(dst, &dst_st) == 0) {
        have_dst = 1;
    }
    if ((have_dst != 0) && (dst_st.st_dev == sst->st_dev) && (dst_st.st_ino == sst->st_ino)) {
        log_msg(LOG_ERROR, "'%s' and '%s' are the same file", src, dst);
        return -1;
    }
    /* -c : continue after the bytes already in a (shorter) destination */
    if ((opt->resume != 0) && (have_dst != 0) && IS_REG(dst_st.st_mode) &&
        ((unsigned long long)dst_st.st_size <= total)) {
        offset = (unsigned long long)dst_st.st_size;
    }
    if (opt->show_info != 0) {
        print_file_info("Source", src, sst);
    }
    flags = (unsigned int)O_WRONLY | (unsigned int)O_CREAT;
    flags |= (offset > 0ULL) ? (unsigned int)O_APPEND : (unsigned int)O_TRUNC;
    out = open(dst, (int)flags, FILE_MODE);
    if (out < 0) {
        log_msg(LOG_ERROR, "cannot create '%s': %s", dst, strerror(errno));
        return -1;
    }
    if (offset > 0ULL) {
        say("Resuming '%s' from byte %llu of %llu\n", dst, offset, total);
        if (lseek(in, (off_t)offset, SEEK_SET) < 0) {
            ret = -1;
        }
    }
    if (ret == 0) {
        ret = copy_loop(in, out, opt, offset, total, copied);
    }
    if ((ret == 0) && (opt->preserve != 0) && (fchmod(out, sst->st_mode & PERM_MASK) < 0)) {
        log_msg(LOG_ERROR, "cannot set permissions on '%s': %s", dst, strerror(errno));
        ret = -1;
    }
    if (close(out) < 0) {
        log_msg(LOG_ERROR, "close error on '%s': %s", dst, strerror(errno));
        ret = -1;
    }
    if ((ret == 0) && (opt->show_info != 0) && (stat(dst, &dst_st) == 0)) {
        print_file_info("Destination", dst, &dst_st);
    }
    return ret;
}

/* Returns 0 on success, -1 on failure (the reason has been reported). */
int copy_file(const char *src, const char *dst, const options_t *opt, stats_t *stats)
{
    const double t0 = now_seconds();
    const int in = open(src, O_RDONLY);
    unsigned long long copied = 0ULL;
    struct stat sst;
    int ret = -1;

    if (in < 0) {
        log_msg(LOG_ERROR, "cannot open '%s': %s", src, strerror(errno));
    } else if ((fstat(in, &sst) < 0) || !IS_REG(sst.st_mode)) {
        log_msg(LOG_ERROR, "'%s' is not a regular file", src);
    } else {
        ret = copy_to_dst(in, &sst, src, dst, opt, &copied);
    }
    if (in >= 0) {
        (void)close(in);
    }
    if ((ret == 0) && (opt->verify != 0)) {
        const int v = verify_files(src, dst, opt->buf_size);
        if (v == 0) {
            say("Verified: '%s' matches '%s'\n", dst, src);
        } else {
            if (v > 0) {
                log_msg(LOG_ERROR, "verification FAILED: '%s' differs from '%s'", dst, src);
            }
            ret = -1;
        }
    }
    if (ret == 0) {
        log_msg(LOG_INFO, "copied %s -> %s (%llu bytes)", src, dst, copied);
    } else {
        log_msg(LOG_ERROR, "copy of '%s' to '%s' failed", src, dst);
    }
    stats->bytes = copied;
    stats->seconds = now_seconds() - t0;
    return ret;
}

/* ---------- -v : byte-by-byte comparison ---------- */

/* Returns 0 identical, 1 different, -1 error. */
int verify_files(const char *a, const char *b, size_t bufsize)
{
    const int fa = open(a, O_RDONLY);
    const int fb = open(b, O_RDONLY);
    unsigned char *ba = malloc(bufsize);
    unsigned char *bb = malloc(bufsize);
    int result = 0;
    int eof = 0;

    if ((fa < 0) || (fb < 0) || (ba == NULL) || (bb == NULL)) {
        log_msg(LOG_ERROR, "verify: cannot open files or allocate memory");
        result = -1;
    }
    while ((result == 0) && (eof == 0)) {
        const ssize_t na = read_full(fa, ba, bufsize);
        const ssize_t nb = read_full(fb, bb, bufsize);

        if ((na < 0) || (nb < 0)) {
            log_msg(LOG_ERROR, "verify: read error: %s", strerror(errno));
            result = -1;
        } else if ((na != nb) || (memcmp(ba, bb, (size_t)na) != 0)) {
            result = 1;
        } else {
            if (na == 0) {
                eof = 1;
            }
        }
    }
    free(ba);
    free(bb);
    if (fa >= 0) {
        (void)close(fa);
    }
    if (fb >= 0) {
        (void)close(fb);
    }
    return result;
}

/* ---------- -B : copy with several buffer sizes and compare ---------- */

int run_benchmark(const char *src, const char *dst, const options_t *opt)
{
    static const size_t sizes[] = { 512U, 4096U, 65536U, 1048576U };
    char tmp[PATH_MAX];
    char label[32];
    struct stat st;
    double best_secs = -1.0;
    size_t best = 0U;
    size_t i;
    int ret = 0;

    if ((snprintf(tmp, sizeof(tmp), "%s.bench.tmp", dst) >= (int)sizeof(tmp)) || (stat(src, &st) < 0)) {
        log_msg(LOG_ERROR, "benchmark: bad source or destination path");
        return -1;
    }
    format_size((unsigned long long)st.st_size, label, sizeof(label));
    say("Benchmark: copying '%s' (%s)\n%-12s %-12s %s\n", src, label, "Buffer", "Time (s)", "Speed (MB/s)");
    for (i = 0U; (i < (sizeof(sizes) / sizeof(sizes[0]))) && (ret == 0); i++) {
        options_t o = *opt;
        stats_t s = { 0ULL, 0.0, 0UL, 0UL };

        o.buf_size = sizes[i];
        o.progress = 0;
        o.show_info = 0;
        o.verify = 0;
        o.resume = 0;
        ret = copy_file(src, tmp, &o, &s);
        (void)unlink(tmp);
        if (ret == 0) {
            const double mbps = (s.seconds > 0.0) ? (((double)s.bytes / 1048576.0) / s.seconds) : 0.0;
            format_size(sizes[i], label, sizeof(label));
            say("%-12s %-12.4f %.2f\n", label, s.seconds, mbps);
            log_msg(LOG_INFO, "benchmark buffer=%zu time=%.4fs speed=%.2fMB/s", sizes[i], s.seconds, mbps);
            if ((best_secs < 0.0) || (s.seconds < best_secs)) {
                best_secs = s.seconds;
                best = i;
            }
        }
    }
    if (ret == 0) {
        format_size(sizes[best], label, sizeof(label));
        say("\nFastest buffer size: %s\n", label);
    }
    return ret;
}
