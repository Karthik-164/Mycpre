# mycp - file copy utility using low-level I/O

Linux command-line copy tool in C using system calls (open, read, write, close, lseek, stat,
fchmod, opendir) plus pthreads.

## Build and use
    make                 # builds ./mycp
    ./mycp [options] <source> <destination>

| Option  | Feature                                             |
|---------|-----------------------------------------------------|
| (none)  | basic file copy                                     |
| -b SIZE | buffer size (4096, 64K, 1M ... up to 256M)          |
| -i      | file information (source and destination)           |
| -p      | progress bar                                        |
| -m      | preserve permissions (files and directories)        |
| -r      | recursive directory copy                            |
| -j N    | copy with N threads (with -r)                       |
| -v      | verify the copy byte by byte                        |
| -c      | resume an interrupted copy                          |
| -B      | benchmark: copy with several buffer sizes           |
| -l FILE | timestamped, thread-safe log file                   |

    ./mycp -b 64K -p -i -m big.iso backup.iso
    ./mycp -r -m -v -l backup.log mydir/ backup_dir/
    ./mycp -r -j 4 mydir/ backup_dir/
    ./mycp -c -v big.iso backup.iso        # resume, then confirm identical

## Source layout (4 .c files + 1 header)
    include/mycp.h options/stats types and every function prototype
    src/util.c     logging (timestamps, thread id, mutex), say(), read/write loops, size/path helpers
    src/copy.c     copy_file (levels 1-5, resume), -i info, -p progress, verify_files, -B benchmark
    src/dircopy.c  -r/-j: scan phase builds a linked-list work stack, worker threads pop and copy
    src/main.c     option parsing, summary

### How the threading works (for explaining)
1. One thread scans the tree with opendir/readdir, creates directories, and pushes every regular
   file on a linked list (no recursion: sub-directories wait on a second list).
2. `-j N` threads run `worker()`: lock mutex, pop one file, unlock, copy it, update counters under
   the mutex. One mutex protects the list and the counters.
3. All console output and all log lines go through one global mutex (`say()` / `log_msg()`), so
   lines from different threads never mix and log timestamps are in order.

### Log format
    [2026-11-04 10:15:32.123] [139759205259072] INFO  copied a.txt -> b.txt (1200 bytes)
     date       time.millis      thread id       level  message           (errors also go to stderr)

## Quality checks
Needs: gcc, g++, libgtest-dev, gcovr, cppcheck, valgrind
(`sudo apt install build-essential libgtest-dev gcovr cppcheck valgrind`).

    make test       build and run the 30 GoogleTest tests
    make coverage   tests + line and branch coverage tables (fails below 95 % lines)
    make cppcheck   static analysis (exit 1 on any finding)
    make misra      MISRA C:2012 via cppcheck's addon; allowed deviations: tools/misra_deviations.txt
    make valgrind   memcheck on the unit tests and on a real recursive copy
    make helgrind   data-race check of the multi-threaded copy (-r -j 4)
    make clean

### The 30 tests
helpers (6) | logging and timestamps (3) | single-file copy (11) | directory copy and threads (6) | command line (5)
- **Timestamping**: log lines match the timestamp/thread-id format, the timestamp is "now", and times
  never go backwards, also with 8 threads logging and with an 8-thread directory copy.
- **Multithreading**: parallel copy equals the source tree, counters add up, thread start failures
  fall back to fewer threads, 1000 requested threads are clamped to 64.
- **Error paths**: tests/test_mycp.cpp uses `ld --wrap` to make malloc, read, write, close, opendir, lstat,
  chmod, fchmod or pthread_create fail on demand; `/dev/full` gives a real "disk full".
  Production code contains no test hooks.
