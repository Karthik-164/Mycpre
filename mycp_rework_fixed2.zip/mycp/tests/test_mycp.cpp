// test_mycp.cpp - the whole GoogleTest suite (30 tests):
//   fault injection (--wrap) | helpers | logging + timestamps | single-file copy | directory copy + threads | command line
#include <gtest/gtest.h>

#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <map>
#include <regex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

extern "C" {
#include "mycp.h"
int mycp_main(int argc, char *argv[]);   // main() of main.c, renamed in the test build
}

using std::string;
static const size_t npos = string::npos;

// ------------------------------------------------------------------ fault injection
// The test binary is linked with -Wl,--wrap=<function>, so every call of these libc functions
// made by mycp's code goes through the __wrap_* functions below.  A test can make the next call
// (or the Nth next call) fail once.  Production code is never built with this.

enum { W_MALLOC, W_READ, W_WRITE, W_CLOSE, W_OPENDIR, W_LSTAT, W_CHMOD, W_FCHMOD, W_PTHREAD_CREATE, W_COUNT };

static int g_skip[W_COUNT] = { -1, -1, -1, -1, -1, -1, -1, -1, -1 };   // -1 = never fail
static int g_err[W_COUNT];

// the (skip+1)-th next call of 'which' fails once with errno = err
static void wrap_fail(int which, int skip, int err)
{
    g_err[which] = err;
    __atomic_store_n(&g_skip[which], skip, __ATOMIC_SEQ_CST);
}

static void wrap_reset()
{
    for (int i = 0; i < W_COUNT; i++) { __atomic_store_n(&g_skip[i], -1, __ATOMIC_SEQ_CST); }
}

// true = this call must fail (thread-safe: worker threads call wrapped functions too)
static bool hit(int which)
{
    if (__atomic_load_n(&g_skip[which], __ATOMIC_SEQ_CST) < 0) { return false; }
    if (__atomic_fetch_sub(&g_skip[which], 1, __ATOMIC_SEQ_CST) > 0) { return false; }
    errno = g_err[which];
    return true;
}

extern "C" {
void *__real_malloc(size_t n);
ssize_t __real_read(int fd, void *b, size_t n);
ssize_t __real_write(int fd, const void *b, size_t n);
int __real_close(int fd);
DIR *__real_opendir(const char *p);
int __real_lstat(const char *p, struct stat *st);
int __real_chmod(const char *p, mode_t m);
int __real_fchmod(int fd, mode_t m);
int __real_pthread_create(pthread_t *t, const pthread_attr_t *a, void *(*f)(void *), void *arg);

void *__wrap_malloc(size_t n)                          { return hit(W_MALLOC) ? nullptr : __real_malloc(n); }
ssize_t __wrap_read(int fd, void *b, size_t n)         { return hit(W_READ) ? -1 : __real_read(fd, b, n); }
ssize_t __wrap_write(int fd, const void *b, size_t n)  { return hit(W_WRITE) ? -1 : __real_write(fd, b, n); }
DIR *__wrap_opendir(const char *p)                     { return hit(W_OPENDIR) ? nullptr : __real_opendir(p); }
int __wrap_lstat(const char *p, struct stat *st)       { return hit(W_LSTAT) ? -1 : __real_lstat(p, st); }
int __wrap_chmod(const char *p, mode_t m)              { return hit(W_CHMOD) ? -1 : __real_chmod(p, m); }
int __wrap_fchmod(int fd, mode_t m)                    { return hit(W_FCHMOD) ? -1 : __real_fchmod(fd, m); }

int __wrap_close(int fd)                               // really closes, then reports the failure
{
    const int r = __real_close(fd);
    return hit(W_CLOSE) ? -1 : r;
}

int __wrap_pthread_create(pthread_t *t, const pthread_attr_t *a, void *(*f)(void *), void *arg)
{
    return hit(W_PTHREAD_CREATE) ? EAGAIN : __real_pthread_create(t, a, f, arg);
}
}   // extern "C"

// ------------------------------------------------------------------ helpers

static string slurp(const string &p) { std::ifstream f(p, std::ios::binary); std::ostringstream s; s << f.rdbuf(); return s.str(); }
static void spit(const string &p, const string &d) { std::ofstream f(p, std::ios::binary); f << d; }

static string data(size_t n)                       // deterministic pseudo-random bytes
{
    string s(n, '\0');
    unsigned x = 12345U;
    for (auto &c : s) { x = x * 1103515245U + 12345U; c = static_cast<char>(x >> 16); }
    return s;
}

static options_t opts() { options_t o{}; o.buf_size = 4096; o.threads = 1; return o; }
static unsigned mode_of(const string &p) { struct stat st; EXPECT_EQ(stat(p.c_str(), &st), 0); return st.st_mode & 07777U; }
static bool contains(const string &s, const string &needle) { return s.find(needle) != npos; }

// Redirect fd 1 (stdout) or fd 2 (stderr) into a temp file until stop().
class Capture {
public:
    explicit Capture(int fd) : fd_(fd) { fflush(stdout); saved_ = dup(fd); tmp_ = tmpfile(); dup2(fileno(tmp_), fd); }
    string stop() {
        fflush(stdout); dup2(saved_, fd_); close(saved_); rewind(tmp_);
        string s; char b[4096]; size_t n;
        while ((n = fread(b, 1, sizeof b, tmp_)) > 0) { s.append(b, n); }
        fclose(tmp_);
        return s;
    }
private:
    int fd_, saved_; FILE *tmp_;
};

// relative path -> content ("<dir>" for directories); symlinks / fifos are ignored like mycp ignores them
static std::map<string, string> snapshot(const string &root)
{
    std::map<string, string> m;
    for (auto &e : std::filesystem::recursive_directory_iterator(root)) {
        const auto t = e.symlink_status().type();
        const string rel = std::filesystem::relative(e.path(), root).string();
        if (t == std::filesystem::file_type::directory) { m[rel] = "<dir>"; }
        else if (t == std::filesystem::file_type::regular) { m[rel] = slurp(e.path().string()); }
    }
    return m;
}

// src/{top.txt, zero, a/x, a/b/y, empty/, link -> top.txt, pipe}  (4 regular files)
static void build_tree(const string &r)
{
    std::filesystem::create_directories(r + "/a/b");
    std::filesystem::create_directories(r + "/empty");
    spit(r + "/top.txt", data(5000)); spit(r + "/zero", ""); spit(r + "/a/x", data(300)); spit(r + "/a/b/y", data(70000));
    std::filesystem::create_symlink("top.txt", r + "/link");
    mkfifo((r + "/pipe").c_str(), 0600);
}

// "[2026-11-04 10:15:32.123] [thread-id] LEVEL message"
static const std::regex kLine(R"(^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})\] \[(\d+)\] (INFO |ERROR) (.*)$)");

static std::vector<string> lines_of(const string &text)
{
    std::vector<string> v; std::istringstream in(text); string l;
    while (std::getline(in, l)) { v.push_back(l); }
    return v;
}

static void expect_log_wellformed(const std::vector<string> &lines)   // format + timestamps never go backwards
{
    string prev;
    for (const auto &l : lines) {
        std::smatch m;
        ASSERT_TRUE(std::regex_match(l, m, kLine)) << l;
        EXPECT_GE(m[1].str(), prev);
        prev = m[1].str();
    }
}

struct CliResult { int rc; string out, err; };
static CliResult cli(std::vector<string> args)
{
    std::vector<char *> av; string prog = "mycp";
    av.push_back(prog.data());
    for (auto &a : args) { av.push_back(a.data()); }
    av.push_back(nullptr);
    Capture co(1), ce(2);
    optind = 0;                                   // let getopt start again
    CliResult r; r.rc = mycp_main(static_cast<int>(args.size()) + 1, av.data());
    r.err = ce.stop(); r.out = co.stop();
    return r;
}

class MyCp : public ::testing::Test {
protected:
    string dir;
    void SetUp() override { char t[] = "/tmp/mycp_ut_XXXXXX"; dir = mkdtemp(t); umask(022); wrap_reset(); }
    void TearDown() override {
        wrap_reset(); log_close();
        const string cmd = "chmod -R u+rwx '" + dir + "' 2>/dev/null; rm -rf '" + dir + "'";
        if (system(cmd.c_str()) != 0) { fprintf(stderr, "cleanup of %s failed\n", dir.c_str()); }
    }
    string p(const string &name) const { return dir + "/" + name; }
    string make(const string &name, size_t size) { spit(p(name), data(size)); return p(name); }
    string long_path(const string &base, size_t len) const {      // existing dir written as base/././././...
        string s = base + "/";
        while (s.size() < len) { s += "./"; }
        return s;
    }
};

// ------------------------------------------------------------------ helpers (util.c)

TEST(Util, ParseSizeAcceptsNumbersAndKM)
{
    size_t v = 0;
    EXPECT_EQ(parse_size("4096", &v), 0); EXPECT_EQ(v, size_t{4096});
    EXPECT_EQ(parse_size("64K", &v), 0);  EXPECT_EQ(v, size_t{65536});
    EXPECT_EQ(parse_size("64k", &v), 0);  EXPECT_EQ(v, size_t{65536});
    EXPECT_EQ(parse_size("1M", &v), 0);   EXPECT_EQ(v, size_t{1048576});
    EXPECT_EQ(parse_size("1m", &v), 0);   EXPECT_EQ(v, size_t{1048576});
    EXPECT_EQ(parse_size("256M", &v), 0); EXPECT_EQ(v, size_t{268435456});
}

TEST(Util, ParseSizeRejectsBadInput)
{
    size_t v = 7;
    for (const char *s : {"", "abc", "0", "-5", " 5", "12X", "1KB", "1G", "257M", "262145K", "99999999999999999999999"}) {
        EXPECT_EQ(parse_size(s, &v), -1) << s;
    }
    EXPECT_EQ(v, size_t{7});                       // untouched on failure
}

TEST(Util, FormatSizeUsesBinaryUnits)
{
    char b[32];
    format_size(0, b, sizeof b);          EXPECT_STREQ(b, "0 B");
    format_size(1023, b, sizeof b);       EXPECT_STREQ(b, "1023 B");
    format_size(1536, b, sizeof b);       EXPECT_STREQ(b, "1.50 KB");
    format_size(5ULL << 20, b, sizeof b); EXPECT_STREQ(b, "5.00 MB");
    format_size(3ULL << 30, b, sizeof b); EXPECT_STREQ(b, "3.00 GB");
    format_size(~0ULL, b, sizeof b);      EXPECT_STREQ(b, "16777216.00 TB");
}

TEST(Util, PathHelpers)
{
    char o[16];
    EXPECT_EQ(join_path(o, sizeof o, "dir", "f"), 0);   EXPECT_STREQ(o, "dir/f");
    EXPECT_EQ(join_path(o, sizeof o, "dir/", "f"), 0);  EXPECT_STREQ(o, "dir/f");
    EXPECT_EQ(join_path(o, 8, "abcdef", "ghi"), -1);    // does not fit
    EXPECT_STREQ(base_name("a/b/c.txt"), "c.txt");
    EXPECT_STREQ(base_name("plain"), "plain");
    EXPECT_STREQ(base_name("dir/"), "");
}

TEST_F(MyCp, WriteAllAndReadFullRetryAndReportErrors)
{
    const string d = data(10000);
    const int fd = open(p("io").c_str(), O_RDWR | O_CREAT, 0600);
    char buf[20000];
    ASSERT_GE(fd, 0);
    EXPECT_EQ(write_all(fd, d.data(), d.size()), 0);
    wrap_fail(W_WRITE, 0, EINTR);                              // interrupted once -> retried
    EXPECT_EQ(write_all(fd, "xyz", 3), 0);
    lseek(fd, 0, SEEK_SET);
    wrap_fail(W_READ, 0, EINTR);
    EXPECT_EQ(read_full(fd, buf, sizeof buf), ssize_t{10003}); // stops at end of file
    EXPECT_EQ(string(buf, 10000), d);
    wrap_fail(W_READ, 0, EIO);   EXPECT_EQ(read_full(fd, buf, 10), ssize_t{-1});
    wrap_fail(W_WRITE, 0, ENOSPC); EXPECT_EQ(write_all(fd, "x", 1), -1);
    wrap_reset();
    close(fd);
    EXPECT_EQ(write_all(fd, "x", 1), -1);                      // closed descriptor
}

TEST(Util, NowSecondsIsMonotonic)
{
    const double a = now_seconds();
    usleep(20000);
    const double b = now_seconds();
    EXPECT_GE(b - a, 0.015);
    EXPECT_LT(b - a, 2.0);
}

// ------------------------------------------------------------------ logging and timestamps

TEST_F(MyCp, LogWithoutFileOpenFailureAndLongMessage)
{
    Capture cap(2);
    EXPECT_EQ(log_open("/nonexistent_dir/x.log"), -1);
    log_msg(LOG_INFO, "nobody listens");                       // no log open: ignored
    log_msg(LOG_ERROR, "boom %d", 42);                         // errors still reach stderr
    const string err = cap.stop();
    EXPECT_TRUE(contains(err, "cannot open log file"));
    EXPECT_TRUE(contains(err, "mycp: boom 42"));
    EXPECT_FALSE(contains(err, "nobody"));

    ASSERT_EQ(log_open(p("long.log").c_str()), 0);
    log_msg(LOG_INFO, "%s", string(3000, 'x').c_str());        // cut to one whole line
    log_close();
    const auto lines = lines_of(slurp(p("long.log")));
    ASSERT_EQ(lines.size(), size_t{1});
    EXPECT_LT(lines[0].size(), size_t{1024});
    expect_log_wellformed(lines);
}

TEST_F(MyCp, LogLinesCarryCurrentTimestampThreadIdAndLevel)
{
    ASSERT_EQ(log_open(p("a.log").c_str()), 0);
    const time_t before = time(nullptr);
    log_msg(LOG_INFO, "hello %s", "world");
    { Capture c(2); log_msg(LOG_ERROR, "bad thing"); c.stop(); }
    const time_t after = time(nullptr);
    log_close();

    const auto lines = lines_of(slurp(p("a.log")));
    ASSERT_EQ(lines.size(), size_t{2});
    expect_log_wellformed(lines);
    std::smatch m;
    ASSERT_TRUE(std::regex_match(lines[0], m, kLine));
    EXPECT_EQ(m[3].str(), "INFO ");
    EXPECT_EQ(m[4].str(), "hello world");
    struct tm tm{};
    ASSERT_TRUE(strptime(m[1].str().c_str(), "%Y-%m-%d %H:%M:%S", &tm) != nullptr);
    tm.tm_isdst = -1;
    EXPECT_GE(mktime(&tm), before);                            // timestamp is "now"
    EXPECT_LE(mktime(&tm), after);
    ASSERT_TRUE(std::regex_match(lines[1], m, kLine));
    EXPECT_EQ(m[3].str(), "ERROR");
    EXPECT_EQ(m[4].str(), "bad thing");
}

TEST_F(MyCp, LogIsThreadSafeAndInTimeOrder)
{
    ASSERT_EQ(log_open(p("mt.log").c_str()), 0);
    std::vector<std::thread> th;
    for (int t = 0; t < 8; t++) {
        th.emplace_back([t] { for (int i = 0; i < 100; i++) { log_msg(LOG_INFO, "thread %d seq %d", t, i); } });
    }
    for (auto &x : th) { x.join(); }
    log_close();

    const auto lines = lines_of(slurp(p("mt.log")));
    ASSERT_EQ(lines.size(), size_t{800});                      // none lost, none torn
    expect_log_wellformed(lines);
    int next[8] = {};
    for (const auto &l : lines) {
        std::smatch m; int t = -1, i = -1;
        ASSERT_TRUE(std::regex_match(l, m, kLine));
        ASSERT_EQ(sscanf(m[4].str().c_str(), "thread %d seq %d", &t, &i), 2);
        ASSERT_EQ(i, next[t]);                                 // each thread's lines stay in order
        next[t]++;
    }
}

// ------------------------------------------------------------------ single-file copy

TEST_F(MyCp, CopyIsByteExactForManySizesAndBuffers)
{
    options_t o = opts();
    for (size_t size : {0, 1, 4095, 4096, 4097, 100000}) {
        for (size_t buf : {3, 4096, 1 << 20}) {
            stats_t st{};
            spit(p("src"), data(size));
            o.buf_size = buf;
            EXPECT_EQ(copy_file(p("src").c_str(), p("dst").c_str(), &o, &st), 0);
            EXPECT_TRUE(slurp(p("dst")) == data(size)) << size << "/" << buf;
            EXPECT_EQ(st.bytes, static_cast<unsigned long long>(size));
            EXPECT_GE(st.seconds, 0.0);
        }
    }
}

TEST_F(MyCp, CopyReportsSourceAndDestinationProblems)
{
    options_t o = opts(); stats_t st{};
    const string f = make("f", 100);
    Capture cap(2);
    EXPECT_EQ(copy_file(p("missing").c_str(), p("out").c_str(), &o, &st), -1);
    EXPECT_EQ(copy_file(dir.c_str(), p("out").c_str(), &o, &st), -1);            // directory
    EXPECT_EQ(copy_file(f.c_str(), p("no_dir/out").c_str(), &o, &st), -1);       // cannot create
    EXPECT_EQ(copy_file(f.c_str(), f.c_str(), &o, &st), -1);                     // onto itself
    ASSERT_EQ(link(f.c_str(), p("hard").c_str()), 0);
    EXPECT_EQ(copy_file(f.c_str(), p("hard").c_str(), &o, &st), -1);             // hard link = same file
    const string err = cap.stop();
    for (const char *s : {"cannot open", "not a regular file", "cannot create", "same file"}) { EXPECT_TRUE(contains(err, s)) << s; }
    EXPECT_TRUE(slurp(f) == data(100));
}

TEST_F(MyCp, CopyHandlesIoAndAllocationFailures)
{
    options_t o = opts(); stats_t st{};
    const string f = make("f", 5000);
    Capture cap(2);
    EXPECT_EQ(copy_file(f.c_str(), "/dev/full", &o, &st), -1);                   // ENOSPC while writing
    wrap_fail(W_READ, 0, EIO);        EXPECT_EQ(copy_file(f.c_str(), p("o1").c_str(), &o, &st), -1);
    wrap_fail(W_MALLOC, 0, ENOMEM);   EXPECT_EQ(copy_file(f.c_str(), p("o2").c_str(), &o, &st), -1);
    wrap_fail(W_CLOSE, 0, EIO);       EXPECT_EQ(copy_file(f.c_str(), p("o3").c_str(), &o, &st), -1);
    o.preserve = 1;
    wrap_fail(W_FCHMOD, 0, EPERM);    EXPECT_EQ(copy_file(f.c_str(), p("o4").c_str(), &o, &st), -1);
    wrap_reset();
    const string err = cap.stop();
    for (const char *s : {"write error", "read error", "out of memory", "close error", "cannot set permissions"}) { EXPECT_TRUE(contains(err, s)) << s; }
}

TEST_F(MyCp, ResumeContinuesAPartialCopy)
{
    const string d = data(70000), src = p("src"), dst = p("dst");
    options_t o = opts(); stats_t st{};
    o.resume = 1; o.verify = 1;
    spit(src, d);
    spit(dst, d.substr(0, 30000));
    Capture cap(1);
    EXPECT_EQ(copy_file(src.c_str(), dst.c_str(), &o, &st), 0);
    const string out = cap.stop();
    EXPECT_TRUE(contains(out, "from byte 30000 of 70000"));
    EXPECT_TRUE(contains(out, "Verified"));
    EXPECT_TRUE(slurp(dst) == d);
    EXPECT_EQ(st.bytes, 40000ULL);                                               // only the missing part

    Capture cap2(1);
    spit(dst, data(90000));                                                      // bigger than source: start over
    EXPECT_EQ(copy_file(src.c_str(), dst.c_str(), &o, &st), 0);
    EXPECT_TRUE(slurp(dst) == d);
    EXPECT_EQ(copy_file(src.c_str(), dst.c_str(), &o, &st), 0);                  // already complete
    EXPECT_EQ(st.bytes, 0ULL);
    cap2.stop();
}

TEST_F(MyCp, VerifyCatchesAResumedCopyWithCorruptStart)
{
    options_t o = opts(); stats_t st{};
    o.resume = 1; o.verify = 1;
    const string src = make("src", 50000);
    spit(p("dst"), string(10000, 'Z'));                                          // resume trusts these bytes
    Capture cap(2), out(1);
    EXPECT_EQ(copy_file(src.c_str(), p("dst").c_str(), &o, &st), -1);
    out.stop();
    EXPECT_TRUE(contains(cap.stop(), "verification FAILED"));
}

TEST_F(MyCp, PreserveFlagControlsPermissions)
{
    options_t o = opts(); stats_t st{};
    const string src = make("src", 10);
    ASSERT_EQ(chmod(src.c_str(), 0751), 0);
    EXPECT_EQ(copy_file(src.c_str(), p("plain").c_str(), &o, &st), 0);
    o.preserve = 1;
    EXPECT_EQ(copy_file(src.c_str(), p("kept").c_str(), &o, &st), 0);
    EXPECT_EQ(mode_of(p("plain")), 0644U);                                       // default mode (umask applied)
    EXPECT_EQ(mode_of(p("kept")), 0751U);
}

TEST_F(MyCp, InfoAndProgressAreDisplayed)
{
    options_t o = opts(); stats_t st{};
    o.show_info = 1; o.progress = 1; o.buf_size = 1000;
    const string src = make("src", 10000);
    Capture cap(1);
    EXPECT_EQ(copy_file(src.c_str(), p("dst").c_str(), &o, &st), 0);
    string out = cap.stop();
    for (const char *s : {"Source file info", "Destination file info", "Size        : 10000 bytes",
                          "Permissions : rw-r--r-- (0644)", "100%", "##############################"}) {
        EXPECT_TRUE(contains(out, s)) << s;
    }
    EXPECT_EQ(out.back(), '\n');                                                 // bar ends with a newline

    Capture cap2(1);                                                             // empty file: nothing to draw
    EXPECT_EQ(copy_file(make("empty", 0).c_str(), p("e2").c_str(), &o, &st), 0);
    EXPECT_FALSE(contains(cap2.stop(), "\r["));
}

TEST_F(MyCp, VerifyFilesComparesContent)
{
    const string a = make("a", 20000), b = make("b", 20000);
    string d = data(20000);
    d[12345] ^= 1;
    spit(p("c"), d);                                                             // one byte differs
    make("d", 19999);                                                            // shorter
    Capture cap(2);
    EXPECT_EQ(verify_files(a.c_str(), b.c_str(), 4096), 0);
    EXPECT_EQ(verify_files(a.c_str(), p("c").c_str(), 4096), 1);
    EXPECT_EQ(verify_files(a.c_str(), p("d").c_str(), 4096), 1);
    EXPECT_EQ(verify_files(a.c_str(), p("missing").c_str(), 4096), -1);
    wrap_fail(W_READ, 0, EIO);        EXPECT_EQ(verify_files(a.c_str(), b.c_str(), 4096), -1);
    wrap_fail(W_MALLOC, 1, ENOMEM);   EXPECT_EQ(verify_files(a.c_str(), b.c_str(), 4096), -1);
    wrap_reset();
    cap.stop();
}

TEST_F(MyCp, BenchmarkTimesSeveralBufferSizes)
{
    options_t o = opts();
    const string src = make("src", 200000);
    Capture cap(1);
    EXPECT_EQ(run_benchmark(src.c_str(), p("out").c_str(), &o), 0);
    const string out = cap.stop();
    for (const char *s : {"512 B", "4.00 KB", "64.00 KB", "1.00 MB", "Fastest buffer size"}) { EXPECT_TRUE(contains(out, s)) << s; }
    EXPECT_FALSE(std::filesystem::exists(p("out.bench.tmp")));                  // temp file removed

    Capture cap2(2), out2(1);
    EXPECT_EQ(run_benchmark(p("missing").c_str(), p("out").c_str(), &o), -1);
    EXPECT_EQ(run_benchmark(src.c_str(), string(5000, 'd').c_str(), &o), -1);    // temp name too long
    EXPECT_EQ(run_benchmark(src.c_str(), p("no_dir/out").c_str(), &o), -1);      // copy fails
    out2.stop();
    cap2.stop();
}

// ------------------------------------------------------------------ directory copy and threads

TEST_F(MyCp, RecursiveCopyReproducesTreeAndSkipsSpecialFiles)
{
    build_tree(p("src"));
    ASSERT_EQ(log_open(p("run.log").c_str()), 0);
    options_t o = opts(); stats_t st{};
    Capture cap(1);
    EXPECT_EQ(copy_directory(p("src").c_str(), p("dst").c_str(), &o, &st), 0);
    EXPECT_TRUE(snapshot(p("dst")) == snapshot(p("src")));
    EXPECT_EQ(st.files_ok, 4UL);
    EXPECT_EQ(st.files_failed, 0UL);
    EXPECT_EQ(st.bytes, 75300ULL);
    EXPECT_EQ(copy_directory(p("src").c_str(), p("dst").c_str(), &o, &st), 0);   // onto an existing copy
    cap.stop();
    log_close();
    const string log = slurp(p("run.log"));
    size_t skipped = 0;
    for (size_t pos = log.find("skipping"); pos != npos; pos = log.find("skipping", pos + 1)) { skipped++; }
    EXPECT_EQ(skipped, size_t{4});                                               // link + pipe, twice
}

TEST_F(MyCp, ParallelCopyMatchesInputAndLogsInTimeOrder)
{
    unsigned long long total = 0;
    for (int d = 0; d < 10; d++) {
        std::filesystem::create_directories(p("src/d" + std::to_string(d)));
        for (int i = 0; i < 20; i++) {
            const size_t n = static_cast<size_t>(((d * 20 + i) * 37) % 9000);
            spit(p("src/d" + std::to_string(d) + "/f" + std::to_string(i)), data(n));
            total += n;
        }
    }
    ASSERT_EQ(log_open(p("par.log").c_str()), 0);
    options_t o = opts(); stats_t st{};
    o.threads = 8; o.verify = 1;
    Capture cap(1);
    EXPECT_EQ(copy_directory(p("src").c_str(), p("dst").c_str(), &o, &st), 0);
    cap.stop();
    log_close();
    EXPECT_TRUE(snapshot(p("dst")) == snapshot(p("src")));
    EXPECT_EQ(st.files_ok, 200UL);
    EXPECT_EQ(st.bytes, total);
    const auto lines = lines_of(slurp(p("par.log")));
    expect_log_wellformed(lines);                                                // whole lines, time ordered
    size_t copied = 0;
    for (const auto &l : lines) { copied += contains(l, "copied ") ? 1U : 0U; }
    EXPECT_EQ(copied, size_t{200});
}

TEST_F(MyCp, ThreadStartFailuresFallBackToFewerThreads)
{
    build_tree(p("src"));
    options_t o = opts(); stats_t st{};
    o.threads = 4;
    Capture cap(1);
    wrap_fail(W_PTHREAD_CREATE, 0, EAGAIN);                                      // no thread: main thread copies
    EXPECT_EQ(copy_directory(p("src").c_str(), p("d1").c_str(), &o, &st), 0);
    wrap_fail(W_PTHREAD_CREATE, 1, EAGAIN);                                      // one thread only
    EXPECT_EQ(copy_directory(p("src").c_str(), p("d2").c_str(), &o, &st), 0);
    wrap_reset();
    o.threads = 1000;                                                            // clamped to MAX_THREADS
    EXPECT_EQ(copy_directory(p("src").c_str(), p("d3").c_str(), &o, &st), 0);
    cap.stop();
    for (const char *d : {"d1", "d2", "d3"}) { EXPECT_TRUE(snapshot(p(d)) == snapshot(p("src"))) << d; }
    EXPECT_EQ(st.files_ok, 4UL);
}

TEST_F(MyCp, PreserveKeepsDirectoryAndFilePermissions)
{
    const string s = p("src");
    for (const char *d : {"src/open", "src/closed", "src/private"}) { std::filesystem::create_directories(p(d)); }
    spit(s + "/closed/f", "data"); chmod((s + "/closed/f").c_str(), 0640);
    chmod((s + "/open").c_str(), 0755); chmod((s + "/closed").c_str(), 0555);
    chmod((s + "/private").c_str(), 0700); chmod(s.c_str(), 0750);
    options_t o = opts(); stats_t st{};
    o.preserve = 1;
    Capture cap(2), out(1);
    EXPECT_EQ(copy_directory(s.c_str(), p("dst").c_str(), &o, &st), 0);          // 0555 dir still gets its file
    EXPECT_EQ(mode_of(p("dst")), 0750U);
    EXPECT_EQ(mode_of(p("dst/open")), 0755U);
    EXPECT_EQ(mode_of(p("dst/closed")), 0555U);
    EXPECT_EQ(mode_of(p("dst/private")), 0700U);
    EXPECT_EQ(mode_of(p("dst/closed/f")), 0640U);
    o.preserve = 0;
    EXPECT_EQ(copy_directory(s.c_str(), p("plain").c_str(), &o, &st), 0);
    EXPECT_EQ(mode_of(p("plain/private")), 0755U);                               // default directory mode
    o.preserve = 1;
    wrap_fail(W_CHMOD, 0, EPERM);
    EXPECT_EQ(copy_directory(s.c_str(), p("dst2").c_str(), &o, &st), 0);         // reported, not fatal
    wrap_reset();
    out.stop();
    EXPECT_TRUE(contains(cap.stop(), "cannot set permissions"));
}

TEST_F(MyCp, DestinationInsideSourceIsNotCopiedIntoItself)
{
    build_tree(p("src"));
    options_t o = opts(); stats_t st{};
    Capture cap(1);
    EXPECT_EQ(copy_directory(p("src").c_str(), p("src/out").c_str(), &o, &st), 0);
    cap.stop();
    EXPECT_TRUE(std::filesystem::exists(p("src/out/top.txt")));
    EXPECT_FALSE(std::filesystem::exists(p("src/out/out")));
    EXPECT_EQ(st.files_ok, 4UL);
}

TEST_F(MyCp, DirectoryCopyReportsProblems)
{
    build_tree(p("src"));
    options_t o = opts(); stats_t st{};
    Capture cap(2), out(1);
    EXPECT_EQ(copy_directory(p("missing").c_str(), p("d0").c_str(), &o, &st), -1);
    spit(p("afile"), "x");
    EXPECT_EQ(copy_directory(p("src").c_str(), p("afile").c_str(), &o, &st), -1);        // destination is a file
    EXPECT_EQ(copy_directory(p("src").c_str(), p("nodir/x").c_str(), &o, &st), -1);      // cannot create it
    std::filesystem::create_directories(p("d4/top.txt"));                                // blocks one file
    EXPECT_EQ(copy_directory(p("src").c_str(), p("d4").c_str(), &o, &st), -1);
    EXPECT_EQ(st.files_failed, 1UL);
    EXPECT_EQ(st.files_ok, 3UL);
    wrap_fail(W_OPENDIR, 0, EACCES);  EXPECT_EQ(copy_directory(p("src").c_str(), p("d5").c_str(), &o, &st), -1);
    wrap_fail(W_LSTAT, 0, EIO);       EXPECT_EQ(copy_directory(p("src").c_str(), p("d6").c_str(), &o, &st), -1);
    wrap_reset();
    std::filesystem::create_directories(p("long/real"));
    spit(p("long/real/a_rather_long_file_name.txt"), "x");
    EXPECT_EQ(copy_directory(long_path(p("long/real"), 4080).c_str(), p("d7").c_str(), &o, &st), -1);
    out.stop();
    const string err = cap.stop();
    for (const char *s : {"cannot stat", "not a directory", "cannot create directory", "cannot open directory", "path too long"}) {
        EXPECT_TRUE(contains(err, s)) << s;
    }
}

TEST_F(MyCp, OutOfMemoryWhileScanningOrCopyingIsHandled)
{
    build_tree(p("src"));
    options_t o = opts(); stats_t st{};
    Capture cap(2), out(1);
    for (int k = 0; k < 10; k++) {                                               // fail the k-th allocation
        wrap_fail(W_MALLOC, k, ENOMEM);
        EXPECT_EQ(copy_directory(p("src").c_str(), p("d" + std::to_string(k)).c_str(), &o, &st), -1) << k;
        wrap_reset();
    }
    out.stop();
    EXPECT_TRUE(contains(cap.stop(), "out of memory"));
}

// ------------------------------------------------------------------ command line (main.c)

TEST_F(MyCp, CliHelpAndArgumentErrors)
{
    const string f = make("f", 10);
    CliResult r = cli({"-h"});
    EXPECT_EQ(r.rc, 0);
    EXPECT_TRUE(contains(r.out, "Usage:"));
    EXPECT_EQ(cli({}).rc, 1);
    EXPECT_EQ(cli({f}).rc, 1);
    EXPECT_EQ(cli({"-z", f, p("o")}).rc, 1);
    r = cli({"-b", "zzz", f, p("o")});
    EXPECT_EQ(r.rc, 1);
    EXPECT_TRUE(contains(r.err, "invalid buffer size"));
    for (const char *j : {"0", "65", "x", "4x"}) {
        r = cli({"-j", j, f, p("o")});
        EXPECT_EQ(r.rc, 1) << j;
        EXPECT_TRUE(contains(r.err, "invalid thread count")) << j;
    }
    EXPECT_EQ(cli({"-l", "/nonexistent_dir/x.log", f, p("o")}).rc, 1);
}

TEST_F(MyCp, CliCopiesFilesWithOptionsAndLog)
{
    const string f = make("f", 70000);
    CliResult r = cli({"-b", "64K", "-i", "-p", "-m", "-v", "-l", p("cli.log"), f, p("g")});
    EXPECT_EQ(r.rc, 0);
    for (const char *s : {"Copied", "---- Summary ----", "Bytes copied : 70000", "Verified"}) { EXPECT_TRUE(contains(r.out, s)) << s; }
    EXPECT_TRUE(slurp(p("g")) == slurp(f));

    std::filesystem::create_directories(p("d"));
    EXPECT_EQ(cli({f, p("d")}).rc, 0);                                           // into an existing directory
    EXPECT_TRUE(std::filesystem::exists(p("d/f")));

    EXPECT_EQ(cli({"-l", p("cli.log"), p("missing"), p("x")}).rc, 1);
    EXPECT_EQ(cli({p("d"), p("x")}).rc, 1);                                      // directory without -r
    const auto lines = lines_of(slurp(p("cli.log")));
    expect_log_wellformed(lines);
    const string log = slurp(p("cli.log"));
    EXPECT_TRUE(contains(log, "mycp started"));
    EXPECT_TRUE(contains(log, "mycp finished: success"));
    EXPECT_TRUE(contains(log, "mycp finished: failure"));                        // log is appended to
}

TEST_F(MyCp, CliDirectoryCopyWithThreadsAndBenchmark)
{
    build_tree(p("src"));
    CliResult r = cli({"-r", "-j", "4", "-p", "-i", "-m", p("src"), p("dst")});
    EXPECT_EQ(r.rc, 0);
    for (const char *s : {"Note: progress bar and file info are disabled", "Files copied : 4", "Files failed : 0"}) { EXPECT_TRUE(contains(r.out, s)) << s; }
    EXPECT_TRUE(snapshot(p("dst")) == snapshot(p("src")));

    const string f = make("f", 30000);
    r = cli({"-B", f, p("bench")});
    EXPECT_EQ(r.rc, 0);
    EXPECT_TRUE(contains(r.out, "Fastest buffer size"));
    EXPECT_EQ(cli({"-B", p("src"), p("bench")}).rc, 1);                          // needs a regular file
}

TEST_F(MyCp, CliResumeWithVerifyDetectsCorruptStart)
{
    const string f = make("f", 50000);
    spit(p("g"), string(1000, 'Z'));
    const CliResult r = cli({"-c", "-v", f, p("g")});
    EXPECT_EQ(r.rc, 1);
    EXPECT_TRUE(contains(r.err, "verification FAILED"));
}

TEST_F(MyCp, CliRejectsTooLongDestinationDirectory)
{
    const string f = make("a_long_source_file_name.bin", 10);
    const CliResult r = cli({f, long_path(dir, 4085)});                                // exists, but name will not fit
    EXPECT_EQ(r.rc, 1);
    EXPECT_TRUE(contains(r.err, "destination path too long"));
}
