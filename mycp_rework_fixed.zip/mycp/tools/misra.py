#!/usr/bin/env python3
"""misra.py - MISRA C:2012 check using cppcheck's misra addon (run from the project root).
Findings in src/ are listed per rule; rules documented in tools/misra_deviations.txt are
reported as deviations.  Exit status 1 if any other finding remains."""
import collections, glob, os, re, shutil, subprocess, sys

CPPCHECK = os.environ.get("CPPCHECK", "cppcheck")
ADDONS = [os.environ.get("MISRA_PY", "")] + [
    "/usr/lib/x86_64-linux-gnu/cppcheck/addons/misra.py", "/usr/share/cppcheck/addons/misra.py",
    "/usr/local/share/cppcheck/addons/misra.py"] + glob.glob("/usr/local/lib/python3*/dist-packages/cppcheck/Cppcheck/addons/misra.py")
misra = next((a for a in ADDONS if a and os.path.exists(a)), None)
if misra is None or shutil.which(CPPCHECK) is None:
    sys.exit("need cppcheck and its misra.py addon (set CPPCHECK=... / MISRA_PY=/path/to/misra.py)")

deviations = {}
for line in open("tools/misra_deviations.txt"):
    if line.strip() and not line.startswith("#"):
        rule, reason = line.split(None, 1)
        deviations[rule] = reason.strip()

os.makedirs("build/misra", exist_ok=True)
os.makedirs("reports", exist_ok=True)
pat = re.compile(r"^\[(src/[^:\]]+):(\d+)\].*\[misra-c2012-([\d.]+)\]")
found = set()
for c_file in sorted(glob.glob("src/*.c")):
    subprocess.run([CPPCHECK, "--dump", "--library=posix", "--platform=unix64", "--std=c11", "-D_GNU_SOURCE",
                    "-D__USE_UNIX98", "-D__USE_XOPEN2K8", "-I/usr/include/x86_64-linux-gnu", "-I/usr/include",
                    "-Isrc", c_file], capture_output=True)
    dump = c_file + ".dump"
    res = subprocess.run([sys.executable, misra, dump], capture_output=True, text=True)
    shutil.move(dump, "build/misra/")
    for line in (res.stderr + res.stdout).splitlines():
        m = pat.match(line)
        if m:
            found.add((m.group(1), int(m.group(2)), m.group(3)))

by_rule = collections.Counter(r for _, _, r in found)
open_items = sorted(f for f in found if f[2] not in deviations)
out = ["MISRA C:2012 (cppcheck addon): %d findings in src/" % len(found), ""]
for rule in sorted(by_rule, key=lambda r: [int(x) for x in r.split(".")]):
    out.append("%-6s %3d  %s" % (rule, by_rule[rule], ("deviation: " + deviations[rule]) if rule in deviations else "TO FIX"))
out += ["", "Not covered by a documented deviation: %d" % len(open_items)]
out += ["  %s:%d  rule %s" % f for f in open_items]
text = "\n".join(out)
print(text)
open("reports/misra_summary.txt", "w").write(text + "\n")
sys.exit(1 if open_items else 0)
