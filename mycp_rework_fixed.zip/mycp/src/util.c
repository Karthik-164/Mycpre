/* util.c - timestamped thread-safe logging, console output, I/O / size / path helpers */
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "mycp.h"

#define MSG_SIZE  768U
#define LINE_SIZE 1024U     /* > MSG_SIZE + longest "[time] [tid] LEVEL " prefix */

static int             g_log_fd = -1;
static pthread_mutex_t g_lock   = PTHREAD_MUTEX_INITIALIZER;   /* serialises ALL output */

/* ---------- logging ---------- */

int log_open(const char *path)
{
    g_log_fd = open(path, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
    if (g_log_fd < 0) {
        (void)fprintf(stderr, "mycp: cannot open log file '%s': %s\n", path, strerror(errno));
        return -1;
    }
    return 0;
}

void log_close(void)
{
    if (g_log_fd >= 0) {
        (void)close(g_log_fd);
        g_log_fd = -1;
    }
}

/* One log line: "[2026-11-04 10:15:32.123] [thread-id] LEVEL message".
 * Errors also go to stderr.  The mutex keeps lines from different threads
 * whole, and the timestamp is taken inside it so lines are in time order. */
void log_msg(log_level_t level, const char *fmt, ...)
{
    char msg[MSG_SIZE];
    char line[LINE_SIZE];
    char stamp[24];
    struct timespec ts;
    struct tm tm;
    va_list ap;
    int n;

    va_start(ap, fmt);
    (void)vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    (void)pthread_mutex_lock(&g_lock);
    (void)clock_gettime(CLOCK_REALTIME, &ts);
    (void)localtime_r(&ts.tv_sec, &tm);
    (void)strftime(stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S", &tm);
    n = snprintf(line, sizeof(line), "[%s.%03ld] [%lu] %-5s %s\n", stamp, ts.tv_nsec / 1000000L,
                 (unsigned long)pthread_self(), (level == LOG_ERROR) ? "ERROR" : "INFO", msg);
    if (level == LOG_ERROR) {
        (void)fprintf(stderr, "mycp: %s\n", msg);
    }
    if ((g_log_fd >= 0) && (n > 0)) {
        (void)write_all(g_log_fd, line, (size_t)n);
    }
    (void)pthread_mutex_unlock(&g_lock);
}

/* printf to stdout under the same mutex, so worker threads cannot interleave */
void say(const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    (void)pthread_mutex_lock(&g_lock);
    (void)vprintf(fmt, ap);
    (void)fflush(stdout);
    (void)pthread_mutex_unlock(&g_lock);
    va_end(ap);
}

/* ---------- I/O loops (partial transfers and EINTR handled) ---------- */

/* Write exactly 'count' bytes. 0 / -1 */
int write_all(int fd, const void *buf, size_t count)
{
    const char *p = buf;
    size_t done = 0U;

    while (done < count) {
        const ssize_t n = write(fd, &p[done], count - done);
        if ((n < 0) && (errno != EINTR)) {
            return -1;
        }
        done += (n > 0) ? (size_t)n : 0U;
    }
    return 0;
}

/* Read until 'count' bytes or EOF. Returns bytes read, or -1 on error. */
ssize_t read_full(int fd, void *buf, size_t count)
{
    char *p = buf;
    size_t got = 0U;

    while (got < count) {
        const ssize_t n = read(fd, &p[got], count - got);
        if (n == 0) {
            break;
        }
        if ((n < 0) && (errno != EINTR)) {
            return -1;
        }
        got += (n > 0) ? (size_t)n : 0U;
    }
    return (ssize_t)got;
}

/* ---------- size / time / path helpers ---------- */

/* "4096", "64K", "1M" -> bytes (1 .. MAX_BUF_SIZE). Returns 0 / -1. */
int parse_size(const char *text, size_t *out)
{
    char *end = NULL;
    unsigned long long mult = 1ULL;
    unsigned long long v;

    if ((text[0] < '0') || (text[0] > '9')) {
        return -1;
    }
    errno = 0;
    v = strtoull(text, &end, 10);
    if (end[0] != '\0') {
        mult = 0ULL;                                    /* unknown suffix */
        if (end[1] == '\0') {
            mult = ((end[0] == 'k') || (end[0] == 'K')) ? 1024ULL : mult;
            mult = ((end[0] == 'm') || (end[0] == 'M')) ? 1048576ULL : mult;
        }
    }
    if ((errno != 0) || (mult == 0ULL) || (v == 0ULL) || (v > (MAX_BUF_SIZE / mult))) {
        return -1;
    }
    *out = (size_t)(v * mult);
    return 0;
}

/* "1.50 MB" style text */
void format_size(unsigned long long bytes, char *out, size_t cap)
{
    static const char *const units[] = { "B", "KB", "MB", "GB", "TB" };
    double v = (double)bytes;
    size_t u = 0U;

    while ((v >= 1024.0) && (u < 4U)) {
        v /= 1024.0;
        u++;
    }
    if (u == 0U) {
        (void)snprintf(out, cap, "%llu B", bytes);
    } else {
        (void)snprintf(out, cap, "%.2f %s", v, units[u]);
    }
}

/* Monotonic clock in seconds (for measuring durations) */
double now_seconds(void)
{
    struct timespec ts;

    (void)clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + ((double)ts.tv_nsec / 1e9);
}

/* out = dir + "/" + name; -1 if it does not fit */
int join_path(char *out, size_t cap, const char *dir, const char *name)
{
    const size_t len = strlen(dir);
    const int n = snprintf(out, cap, "%s%s%s", dir, ((len > 0U) && (dir[len - 1U] == '/')) ? "" : "/", name);

    return ((n >= 0) && ((size_t)n < cap)) ? 0 : -1;
}

/* Last component of a path */
const char *base_name(const char *path)
{
    const char *slash = strrchr(path, '/');

    return (slash != NULL) ? &slash[1] : path;
}
