/* main.c - command line parsing, program flow and summary */
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "mycp.h"

#define OPTSTRING "b:ipmrj:vcBl:h"

static void usage(FILE *f, const char *prog)
{
    (void)fprintf(f,
        "Usage: %s [options] <source> <destination>\n"
        "  -b SIZE  buffer size: 4096, 64K, 1M ...   -i  file info     -p  progress bar\n"
        "  -m       preserve permissions             -v  verify copy   -c  resume copy\n"
        "  -r       copy directories                 -j N  N threads (with -r)\n"
        "  -B       benchmark buffer sizes           -l FILE  timestamped log   -h  help\n", prog);
}

static void print_summary(const stats_t *s, int is_dir)
{
    char size[32];
    const double mbps = (s->seconds > 0.0) ? (((double)s->bytes / 1048576.0) / s->seconds) : 0.0;

    format_size(s->bytes, size, sizeof(size));
    say("\n---- Summary ----\n");
    if (is_dir != 0) {
        say("Files copied : %lu\nFiles failed : %lu\n", s->files_ok, s->files_failed);
    }
    say("Bytes copied : %llu (%s)\nTime taken   : %.4f s\nSpeed        : %.2f MB/s\n",
        s->bytes, size, s->seconds, mbps);
}

/* -j value: 1 .. MAX_THREADS */
static int parse_threads(const char *text, int *out)
{
    char *end = NULL;
    const long v = strtol(text, &end, 10);

    if ((end[0] != '\0') || (v < 1L) || (v > (long)MAX_THREADS)) {
        return -1;
    }
    *out = (int)v;
    return 0;
}

/* Returns 0 = run, 1 = help requested, -1 = error */
static int parse_args(int argc, char *argv[], options_t *opt)
{
    int c;

    for (c = getopt(argc, argv, OPTSTRING); c != -1; c = getopt(argc, argv, OPTSTRING)) {
        switch (c) {
        case 'b':
            if (parse_size(optarg, &opt->buf_size) < 0) {
                log_msg(LOG_ERROR, "invalid buffer size '%s' (1 byte to 256M)", optarg);
                return -1;
            }
            break;
        case 'j':
            if (parse_threads(optarg, &opt->threads) < 0) {
                log_msg(LOG_ERROR, "invalid thread count '%s' (1-%d)", optarg, MAX_THREADS);
                return -1;
            }
            break;
        case 'i': opt->show_info = 1; break;
        case 'p': opt->progress = 1;  break;
        case 'm': opt->preserve = 1;  break;
        case 'r': opt->recursive = 1; break;
        case 'v': opt->verify = 1;    break;
        case 'c': opt->resume = 1;    break;
        case 'B': opt->benchmark = 1; break;
        case 'l': opt->log_path = optarg; break;
        case 'h': return 1;
        default:  return -1;                /* getopt already printed the message */
        }
    }
    return 0;
}

static int run(const options_t *opt, const char *src, const char *dst)
{
    struct stat sst;
    struct stat dt;
    stats_t st = { 0ULL, 0.0, 0UL, 0UL };
    options_t o = *opt;
    char target[PATH_MAX];
    const char *final_dst = dst;
    int rc;

    if (stat(src, &sst) < 0) {
        log_msg(LOG_ERROR, "cannot stat '%s': %s", src, strerror(errno));
        return -1;
    }
    if (opt->benchmark != 0) {
        if (!S_ISREG(sst.st_mode)) {
            log_msg(LOG_ERROR, "benchmark needs a regular file as source");
            return -1;
        }
        return run_benchmark(src, dst, opt);
    }
    if (S_ISDIR(sst.st_mode)) {
        if (opt->recursive == 0) {
            log_msg(LOG_ERROR, "'%s' is a directory (use -r to copy directories)", src);
            return -1;
        }
        if ((o.threads > 1) && ((o.progress != 0) || (o.show_info != 0))) {
            say("Note: progress bar and file info are disabled with multiple threads\n");
            o.progress = 0;
            o.show_info = 0;
        }
        rc = copy_directory(src, dst, &o, &st);
        print_summary(&st, 1);
        return rc;
    }
    /* single file; if dst is an existing directory, copy into it */
    if ((stat(dst, &dt) == 0) && S_ISDIR(dt.st_mode)) {
        if (join_path(target, sizeof(target), dst, base_name(src)) < 0) {
            log_msg(LOG_ERROR, "destination path too long");
            return -1;
        }
        final_dst = target;
    }
    rc = copy_file(src, final_dst, opt, &st);
    if (rc == 0) {
        say("Copied '%s' -> '%s'\n", src, final_dst);
        print_summary(&st, 0);
    }
    return rc;
}

int main(int argc, char *argv[])
{
    options_t opt = { .buf_size = DEFAULT_BUF_SIZE, .threads = 1 };
    const int parsed = parse_args(argc, argv, &opt);
    int rc;

    if (parsed > 0) {
        usage(stdout, argv[0]);
        return EXIT_SUCCESS;
    }
    if ((parsed < 0) || ((argc - optind) != 2)) {
        usage(stderr, argv[0]);
        return EXIT_FAILURE;
    }
    if ((opt.log_path != NULL) && (log_open(opt.log_path) < 0)) {
        return EXIT_FAILURE;
    }
    log_msg(LOG_INFO, "mycp started: '%s' -> '%s' (buffer=%zu)", argv[optind], argv[optind + 1], opt.buf_size);
    rc = run(&opt, argv[optind], argv[optind + 1]);
    log_msg(LOG_INFO, "mycp finished: %s", (rc == 0) ? "success" : "failure");
    log_close();
    return (rc == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
