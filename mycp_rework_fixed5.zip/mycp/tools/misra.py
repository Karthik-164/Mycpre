#!/usr/bin/env python3
"""misra.py - MISRA C:2012 check using cppcheck's misra addon (run from the project root).
Only the rules listed in tools/misra_rules.txt are checked; the result is one PASS/FAIL line
per rule.  The offending source lines are not printed - if a rule fails they are written to
build/misra/violations.txt.  Exit status 1 if any listed rule fails."""
import collections, glob, os, re, shutil, subprocess, sys

CPPCHECK = os.environ.get("CPPCHECK", "cppcheck")
ADDONS = [os.environ.get("MISRA_PY", "")] + [
    "/usr/lib/x86_64-linux-gnu/cppcheck/addons/misra.py", "/usr/share/cppcheck/addons/misra.py",
    "/usr/local/share/cppcheck/addons/misra.py"] + glob.glob("/usr/local/lib/python3*/dist-packages/cppcheck/Cppcheck/addons/misra.py")
misra = next((a for a in ADDONS if a and os.path.exists(a)), None)
if misra is None or shutil.which(CPPCHECK) is None:
    sys.exit("need cppcheck and its misra.py addon (set CPPCHECK=... / MISRA_PY=/path/to/misra.py)")

# the rules to check: "<rule> <description>" per line of tools/misra_rules.txt
rules = collections.OrderedDict()
for line in open("tools/misra_rules.txt"):
    if line.strip() and not line.startswith("#"):
        rule, text = line.split(None, 1)
        rules[rule] = text.strip()

# Work on a copy of src/ and include/ inside build/misra, so the .dump / .ctu-info files that
# cppcheck writes next to each source file never land in the source tree.
WORK = os.path.join("build", "misra")
shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(WORK)
os.makedirs("reports", exist_ok=True)
for d in ("src", "include"):
    shutil.copytree(d, os.path.join(WORK, d))
misra = os.path.abspath(misra)
pat = re.compile(r"^\[((?:src|include)/[^:\]]+):(\d+)\].*\[misra-c2012-([\d.]+)\]")
found = set()
for c_file in sorted(glob.glob("src/*.c")):
    subprocess.run([CPPCHECK, "--dump", "--library=posix", "--platform=unix64", "--std=c11", "-D_GNU_SOURCE",
                    "-D__USE_UNIX98", "-D__USE_XOPEN2K8", "-I/usr/include/x86_64-linux-gnu", "-I/usr/include",
                    "-Iinclude", c_file], cwd=WORK, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    res = subprocess.run([sys.executable, misra, c_file + ".dump"], cwd=WORK, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, universal_newlines=True)
    for line in (res.stderr + res.stdout).splitlines():
        m = pat.match(line)
        if m and m.group(3) in rules:                 # rules that are not in the file are ignored
            found.add((m.group(1), int(m.group(2)), m.group(3)))

count = collections.Counter(r for _, _, r in found)
out = ["MISRA C:2012 check - rules from tools/misra_rules.txt", ""]
for rule, text in rules.items():
    out.append("  Rule %-5s %-5s %s" % (rule, "FAIL" if count[rule] else "PASS", text))
failed = sum(1 for r in rules if count[r])
out += ["", "Result: %d rules checked, %d passed, %d failed" % (len(rules), len(rules) - failed, failed)]
text = "\n".join(out)
print(text)
open("reports/misra_summary.txt", "w").write(text + "\n")
if found:                                             # details go to a file, not to the screen
    with open(os.path.join(WORK, "violations.txt"), "w") as f:
        f.writelines("%s:%d  rule %s\n" % v for v in sorted(found))
sys.exit(1 if failed else 0)
