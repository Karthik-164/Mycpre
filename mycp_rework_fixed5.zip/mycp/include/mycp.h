/* mycp.h - the one header: types, constants and every function shared between files */
#ifndef MYCP_H
#define MYCP_H

#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>

#define DEFAULT_BUF_SIZE 4096U
#define MAX_BUF_SIZE     (256ULL * 1024ULL * 1024ULL)
#define MAX_THREADS      64
#define AUTO_PROGRESS_CHUNKS 64U   /* single file on a terminal: show the bar from this many chunks on */

/* POSIX mode bits as unsigned constants (the <sys/stat.h> macros are signed ints and, being
 * combined with unsigned st_mode, break MISRA 10.1 / 10.4; octal is avoided for MISRA 7.1). */
#define MODE_FMT_MASK 0xF000U                       /* S_IFMT  (0170000) */
#define MODE_REG      0x8000U                       /* S_IFREG (0100000) */
#define MODE_DIR      0x4000U                       /* S_IFDIR (0040000) */
#define IS_REG(m)     (((m) & MODE_FMT_MASK) == MODE_REG)
#define IS_DIR(m)     (((m) & MODE_FMT_MASK) == MODE_DIR)
#define PERM_MASK     0xFFFU                        /* setuid/setgid/sticky + rwxrwxrwx (07777) */
#define FILE_MODE     0x1A4U                        /* rw-r--r--  (0644) */
#define DIR_MODE      0x1EDU                        /* rwxr-xr-x  (0755) */

typedef struct {
    size_t      buf_size;   /* -b : buffer size in bytes            */
    int         buf_chosen; /* 1 = -b was given (no buffer menu)    */
    int         show_info;  /* -i : file information display        */
    int         progress;   /* -p : progress bar                    */
    int         preserve;   /* -m : preserve permissions            */
    int         recursive;  /* -r : recursive directory copy        */
    int         benchmark;  /* -B : buffer-size benchmark           */
    int         verify;     /* -v : byte-by-byte verification       */
    int         resume;     /* -c : resume an interrupted copy      */
    int         threads;    /* -j : worker threads (with -r)        */
    const char *log_path;   /* -l : log file (NULL = no log)        */
} options_t;

typedef struct {
    unsigned long long bytes;
    double             seconds;
    unsigned long      files_ok;
    unsigned long      files_failed;
} stats_t;

typedef enum { LOG_INFO, LOG_ERROR } log_level_t;

/* util.c - logging with timestamps, thread-safe console output, helpers */
int    log_open(const char *path);
void   log_close(void);
void   log_msg(log_level_t level, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void   say(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
int    write_all(int fd, const void *buf, size_t count);
ssize_t read_full(int fd, void *buf, size_t count);
int    parse_size(const char *text, size_t *out);
int    prompt_buffer_size(FILE *in, size_t *out);
void   format_size(unsigned long long bytes, char *out, size_t cap);
double now_seconds(void);
int    join_path(char *out, size_t cap, const char *dir, const char *name);
const char *base_name(const char *path);

/* copy.c - single-file copy, verification, benchmark */
int copy_file(const char *src, const char *dst, const options_t *opt, stats_t *stats);
int verify_files(const char *a, const char *b, size_t bufsize);
int run_benchmark(const char *src, const char *dst, const options_t *opt);

/* dircopy.c - recursive copy with worker threads */
int copy_directory(const char *src, const char *dst, const options_t *opt, stats_t *stats);

#endif
